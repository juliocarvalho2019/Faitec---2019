\c sanguebom

--Tipo Sanguineo
insert into tiposanguineo (tiposangue) values ('O+');
insert into tiposanguineo (tiposangue) values ('O-');
insert into tiposanguineo (tiposangue) values ('A+');
insert into tiposanguineo (tiposangue) values ('A-');
insert into tiposanguineo (tiposangue) values ('B+');
insert into tiposanguineo (tiposangue) values ('B-');
insert into tiposanguineo (tiposangue) values ('AB+');
insert into tiposanguineo (tiposangue) values ('AB-');

--Usuario
insert into usuario (nome, endereco, telefone, email, senha, cpfcnpj, estado, cidade, cep, status, foto, peso, altura, tiposanguineo_id, rg, sexo, tipo) 
	values ('Luis Fernando', 'Rua das Pedras', '99887766', 'luis@hotmail.com', '123456', '123145698', 'MG', 'Santa Rita do Sapucai', '37540000', 0, NULL, 70.0,1.70,1,'12365948','M', 0);
insert into usuario (nome, endereco, telefone, email, senha, cpfcnpj, estado, cidade, cep, status, foto, peso, altura, tiposanguineo_id, rg, sexo, tipo)
 values ('Andre Drauzio', 'Rua das flores', '99997766', 'andre@hotmail.com', '123698','456789658', 'MG', 'Santa Rita do Sapucai', '37540000', 0, NULL, 80.0, 1.80, 2, '15648735', 'M', 0);
insert into usuario (nome, endereco, telefone, email, senha, cpfcnpj, estado, cidade, cep, status, foto, peso, altura, tiposanguineo_id, rg, sexo, tipo)
 values ('Julio Carvalho', 'Rua das Tulipas', '99447766', 'julio@hotmail.com', '123456','21303626904','MG','Santa Rita do Sapucai','37540000', 0, NULL,80.0,1.70,3,'12323035', 'M',0);
insert into usuario (nome, endereco, telefone, email, senha, cpfcnpj, estado, cidade, cep, status, foto, peso, altura, tiposanguineo_id, rg, sexo, tipo) 
	values ('Hemocentro Santa Rita','Rua das flores','99557766','hemocentro.santarita@hotmail.com','123456684','312054128','MG','Santa Rita do Sapucai','37540000', 1, NULL, NULL, NULL, 1, NULL, NULL, 1);
insert into usuario (nome, endereco, telefone, email, senha, cpfcnpj, estado, cidade, cep, status, foto, peso, altura, tiposanguineo_id, rg, sexo, tipo)
 values ('Hemocentro Belo','Rua das loucas','99337766','hemocentrobelo@hotmail.com','123456','265417896','MG','Camburuira','37420000', 1, NULL, NULL, NULL, 1, NULL, NULL, 1);


--Solicitacao
insert into solicitacao (datahora,descricao,usuario_id,hemocentro_id,status) 
	values (now(),'Urgente preciso de sangue O+',1,4,0);
insert into solicitacao (datahora,descricao,usuario_id,hemocentro_id,status) 
	values (now(),'Urgente preciso de sangue O-',2,5,1);


--Campanha
insert into campanha (descricao,nome,datainicio,datafim,status,hemocentro_id,usuario_id) 
	values ('Sangue para minha tia.','Doacao Tia','10/05/2019','20/08/2019',0,4,1);
insert into campanha (descricao,nome,datainicio,datafim,status,hemocentro_id,usuario_id) 
	values ('Sangue para minha irma.','Doacao Irma','10/05/2019','20/08/2019',1,5,2);

--doacao
insert into doacao (datahora,status,usuario_id,campanha_id,solicitacao_id) values (now(),0,1,1,1);
insert into doacao (datahora,status,usuario_id,campanha_id,solicitacao_id) values (now(),1,2,2,2);


--tiposanguineo_solicitacao
insert into tiposanguineo_solicitacao(solicitacao_id,tiposanguineo_id) values (1,1);
insert into tiposanguineo_solicitacao(solicitacao_id,tiposanguineo_id) values (2,2);


--tiposanquineo_campanha
insert into tiposanguineo_campanha(campanha_id,tiposanguineo_id) values (1,1);
insert into tiposanguineo_campanha(campanha_id,tiposanguineo_id) values (2,2);
